/*
 * Task.c
 *
 *  Created on: 1/02/2019
 *      Author: julian
 */


#include "Task/Task.h"


void IdleTask_Callback(qEvent_t e){


}
