/*
 * Event.h
 *
 *  Created on: 1/02/2019
 *      Author: julian
 */

#ifndef EVENT_H_
#define EVENT_H_

#include <Common/Globals.h>
void HAL_SYSTICK_Callback(void);
#endif /* EVENT_H_ */
